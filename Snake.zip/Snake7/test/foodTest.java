import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import javax.swing.JLabel;

import org.junit.Test;

public class foodTest {

	@Test
	public void foodGeneratedCorrectDistance()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        Food f = court.foodList.get(0);
        int headX = court.snk.getHeadX();
        int headY = court.snk.getHeadY();
        
        int foodX = f.getPx();
        int foodY = f.getPy();
        
        int xDist = Math.abs(foodX - headX);
        int yDist = Math.abs(foodY - headY);
        double dist = Math.sqrt(Math.pow(xDist, 2) + Math.pow(yDist, 2));
        if(f.getClass().getName().equals("Apple"))
        {
        	assertTrue(dist < 50);
        }
        else
        {
        	assertTrue(dist > 50);
        }
	}
	
	@Test
	public void appleModifiesScore()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        Food food = new Apple(300, 300, 130, 130, court.snk);
        food.modifyScore();
        assertEquals(GameCourt.score, 6);
	}
	
	@Test
	public void orangeModifiesScore()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        Food food = new Orange(300, 300, 130, 130, court.snk);
        food.modifyScore();
        assertEquals(GameCourt.score, 7);
	}
	
	@Test
	public void poisonModifiesScore()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        Food food = new Poison(300, 300, 130, 130, court.snk);
        food.modifyScore();
        assertEquals(GameCourt.score, 4);
	}
	
	@Test
	public void createOrangeCheckTimer()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        Food food = new Orange(300, 300, 130, 130, court.snk);
        assertEquals(food.getTimer(), 100);
	}
	
}
