import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JLabel;

import org.junit.Test;

public class fileTest {

	@Test
	public void testDataIsAddedToFile() throws IOException
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        File f = new File("files/HighScore");
        f.delete();
        File f1 = new File("files/HighScore");
        GameCourt.setNameTo("Random");
        GameCourt.score = 85;
        court.snk.writeToFile();
        BufferedReader br = new BufferedReader(new FileReader(f1));
        court.snk.sortFileInfo();
        assertEquals(br.readLine(), "Random  85");
	
	}
	
	@Test
	public void testDataIsSortedCorrectly() throws IOException
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        File f = new File("files/HighScore");
        f.delete();
        File f1 = new File("files/HighScore");
        GameCourt.setNameTo("Abcd");
        GameCourt.score = 10;
        court.snk.writeToFile();
        GameCourt.setNameTo("Aakash");
        GameCourt.score = 5;
        court.snk.writeToFile();
        
        GameCourt.setNameTo("Abc");
        GameCourt.score = 8;
        court.snk.writeToFile();
        
        GameCourt.setNameTo("Abcd");
        GameCourt.score = 12;
        court.snk.writeToFile();
        
        GameCourt.setNameTo("Abcd");
        GameCourt.score = 6;
        court.snk.writeToFile();
        
        court.snk.sortFileInfo();
        
        BufferedReader br = new BufferedReader(new FileReader(f1));
        
        assertEquals(br.readLine(), "Random  85");
        assertEquals(br.readLine(), "Abcd    12");
        assertEquals(br.readLine(), "Abcd    10");
        assertEquals(br.readLine(), "Abc     8");
        assertEquals(br.readLine(), "Abcd    6");
        assertEquals(br.readLine(), "Aakash  5");
	}
	
	
}
