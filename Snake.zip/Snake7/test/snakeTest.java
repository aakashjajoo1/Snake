import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.Timer;
import javax.swing.plaf.basic.BasicInternalFrameTitlePane.SystemMenuBar;

import org.junit.Test;

public class snakeTest {

	
	@Test
	public void createSnake()
	{
		Snake snk = new Snake(300, 300);
		assertEquals(snk.getHeadX(), 130);
		assertEquals(snk.getHeadY(), 130);
		assertEquals(snk.getSize(), 5);
	}
	
	@Test
	public void createCourtAndReset()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        
        assertEquals(court.snk.getHeadX(), 130);
		assertEquals(court.snk.getHeadY(), 130);
		assertEquals(court.snk.getSize(), 5);
	}

	@Test
	public void createCourtMove()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        court.snk.move(court);
        assertEquals(court.snk.getHeadX(), 130);
		assertEquals(court.snk.getHeadY(), 120);
		assertEquals(court.snk.getSize(), 5);
		List<Points> snakePoints = court.snk.getSnakePoints();
		assertEquals(snakePoints.get(1).getX(), 130);
		assertEquals(snakePoints.get(1).getY(), 130);
		assertEquals(snakePoints.get(2).getX(), 130);
		assertEquals(snakePoints.get(2).getY(), 140);
	}
	
	@Test
	public void testGetSnakePointsMaintainsEncapsulation()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        List<Points> snakePoints = court.snk.getSnakePoints();
        snakePoints.set(0, new Points(100, 100));
        assertEquals(court.snk.getHeadX(), 130);
        assertEquals(court.snk.getHeadY(), 130);
	}
	
	@Test
	public void MoveAfterChangingDirection()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        court.snk.setDirection(Direction.LEFT);
        court.snk.move(court);
        assertEquals(court.snk.getHeadX(), 120);
        assertEquals(court.snk.getHeadY(), 130);
        List<Points> snakePoints = court.snk.getSnakePoints();
        assertEquals(snakePoints.get(1).getX(), 130);
        assertEquals(snakePoints.get(1).getY(), 130);
	}
	
	@Test
	public void snakeEatsFood()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        Food food = court.foodList.get(0);
        food.setPx(130);
        food.setPy(120);
        assertEquals(GameCourt.score, 5);
        assertEquals(court.snk.getSize(), 5);
        court.tick();
        if(food.getClass().getName().equals("Poison"))
        {
        	assertEquals(GameCourt.score, 4);
        	assertEquals(court.snk.getSize(), 4);
        }
        else if(food.getClass().getName().equals("Apple"))
        {
        	assertEquals(GameCourt.score, 6);
        	assertEquals(court.snk.getSize(), 6);
        }
        else
        {
        	assertEquals(GameCourt.score, 7);
        	assertEquals(court.snk.getSize(), 7);
        }
	}
	
	@Test
	public void snakeEatsTwoApples()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        court.foodList.removeAll(court.foodList);
        Food food = new Apple(300, 300, 130, 130, court.snk);
        court.foodList.add(food);
        food.setPx(130);
        food.setPy(120);
        court.snk.move(court);
        court.foodList.removeAll(court.foodList);
        food = new Apple(300, 300, 130, 130, court.snk);
        court.foodList.add(food);
        food.setPx(130);
        food.setPy(110);
        court.snk.move(court);
        assertEquals(court.snk.getSize(), 7);
	}
	
	@Test
	public void testAddToFoodList()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        court.foodList.removeAll(court.foodList);
        Food f = new Apple(300, 300, 130, 130, court.snk);
        court.addToFoodList(f);
        assertTrue(court.foodList.contains(f));
        assertEquals(court.foodList.size(), 1);
	}
	
	@Test
	public void testHitTopWall()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        while(court.snk.getHeadY() >= 10)
        {
        	court.snk.move(court);
        }
        court.snk.move(court);
        assertFalse(GameCourt.playing);
	}
	
	
	@Test
	public void testRemoveFromFoodList()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        court.foodList.removeAll(court.foodList);
        Food f = new Apple(300, 300, 130, 130, court.snk);
        court.addToFoodList(f);
        court.removeFromFoodList(f);
        assertFalse(court.foodList.contains(f));
        assertEquals(court.foodList.size(), 0);
	}
	
	
	
	@Test
	public void snakeEatsOneAppleAndOneOrange()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        court.foodList.removeAll(court.foodList);
        Food food = new Apple(300, 300, 130, 130, court.snk);
        court.foodList.add(food);
        food.setPx(130);
        food.setPy(120);
        court.snk.move(court);
        court.foodList.removeAll(court.foodList);
        food = new Orange(300, 300, 130, 130, court.snk);
        court.foodList.add(food);
        food.setPx(130);
        food.setPy(110);
        court.snk.move(court);
        assertEquals(court.snk.getSize(), 8);
	}
	
	@Test
	public void snakeDiesIfScoreIsZero()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        court.snk.removeLast();
        court.snk.removeLast();
        court.snk.removeLast();
        court.snk.removeLast();
        assertEquals(court.snk.getSize(), 1);
        System.out.println(court.snk.getSize());
        court.snk.removeLast();
        court.tick();
        assertFalse(GameCourt.playing);
     }
	
	@Test
	public void snakeHeadOutOfBounds()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        GameCourt.setNameTo("ABCD");
        Food f = court.foodList.get(0);
        f.setPx(130);
        f.setPy(0);
        while(court.snk.getHeadY() >= 10)
        {
        	court.tick();
        }
        assertEquals(court.snk.getHeadX(), 130);
        assertEquals(court.snk.getHeadY(), 0);
        court.tick();
        assertFalse(court.playing);
	}

	
	@Test
	public void snakeHeadOutOfBoundsAfterTurningLeft()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        GameCourt.setNameTo("ABCD");
        court.snk.setDirection(Direction.LEFT);
        while(court.snk.getHeadX() >= 10)
        {
        	court.tick();
        }
        assertEquals(court.snk.getHeadX(), 0);
        assertEquals(court.snk.getHeadY(), 130);
        assertTrue(court.playing);
        court.tick();
        assertFalse(court.playing);
	}
	
	@Test
	public void testIncreaseParts()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        court.snk.increaseParts();
        List<Points> x = court.snk.getSnakePoints();
        Points y = x.get(x.size()-1);
        assertEquals(y.getY(), 180);
	}
	
	@Test
	public void testRemoveTail()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        court.snk.removeLast();
        List<Points> x = court.snk.getSnakePoints();
        Points y = x.get(x.size()-1);
        assertEquals(y.getY(), 160);
	}
	
	@Test
	public void snakeHeadOutOfBoundsThenReset()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        GameCourt.setNameTo("ABCD");
        while(court.snk.getHeadY() >= 10)
        {
        	court.tick();
        }
        assertEquals(court.snk.getHeadX(), 130);
        assertEquals(court.snk.getHeadY(), 0);
        court.tick();
        assertFalse(GameCourt.playing);
        
        court.reset();
        
        assertEquals(court.snk.getHeadX(), 130);
		assertEquals(court.snk.getHeadY(), 130);
		assertEquals(court.snk.getSize(), 5);
	}
	
	@Test
	public void testSnakeSelfCollision()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        court.snk.setDirection(Direction.LEFT);
        court.tick();
        court.snk.setDirection(Direction.DOWN);
        court.tick();
        court.snk.setDirection(Direction.RIGHT);
        court.tick();
        assertTrue(court.snk.snakeCollidesWithSelf());
        assertFalse(GameCourt.playing);
	}
	
	@Test
	public void testSnakeSelfCollisionThenGameReset()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        court.snk.setDirection(Direction.LEFT);
        court.tick();
        court.snk.setDirection(Direction.DOWN);
        court.tick();
        court.snk.setDirection(Direction.RIGHT);
        court.tick();
        assertTrue(court.snk.snakeCollidesWithSelf());
        assertFalse(GameCourt.playing);
        court.reset();
        assertTrue(GameCourt.playing);
	}
	
	@Test
	public void testSetAndGetDirection()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        court.snk.setDirection(Direction.LEFT);
        assertEquals(court.snk.getDirection(), Direction.LEFT);
	}
	
	@Test
	public void testPoisonDecreasesLengthAndScore()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        court.foodList.remove(1);
        court.foodList.remove(0);
        Food food = new Poison(300, 300, 130, 130, court.snk);
        court.foodList.add(food);
        food.setPx(130);
        food.setPy(120);
        court.snk.move(court);
        assertEquals(court.snk.getSize(), 4);
	}
	
	
	
	@Test
	public void testEatFivePoisonEndsGame()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        court.foodList.remove(1);
        court.foodList.remove(0);
        Food food = new Poison(300, 300, 130, 130, court.snk);
        court.foodList.add(food);
        food.setPx(130);
        food.setPy(120);
        court.tick();
        court.foodList.remove(0);
        food = new Poison(300, 300, 130, 130, court.snk);
        court.foodList.add(food);
        food.setPx(130);
        food.setPy(110);
        court.tick();
        court.foodList.remove(0);
        food = new Poison(300, 300, 130, 130, court.snk);
        court.foodList.add(food);
        food.setPx(130);
        food.setPy(100);
        court.tick();
        court.foodList.remove(0);
        food = new Poison(300, 300, 130, 130, court.snk);
        court.foodList.add(food);
        food.setPx(130);
        food.setPy(90);
        court.tick();
        court.foodList.remove(0);
        food = new Poison(300, 300, 130, 130, court.snk);
        court.foodList.add(food);
        food.setPx(130);
        food.setPy(80);
        court.tick();
        assertFalse(GameCourt.playing);
	}
	
	@Test
	public void testEatFourPoisonReducesSizeToOne()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        court.foodList.remove(1);
        court.foodList.remove(0);
        Food food = new Poison(300, 300, 130, 130, court.snk);
        court.foodList.add(food);
        food.setPx(130);
        food.setPy(120);
        court.snk.move(court);
        court.foodList.remove(0);
        food = new Poison(300, 300, 130, 130, court.snk);
        court.foodList.add(food);
        food.setPx(130);
        food.setPy(110);
        court.snk.move(court);
        court.foodList.remove(0);
        food = new Poison(300, 300, 130, 130, court.snk);
        court.foodList.add(food);
        food.setPx(130);
        food.setPy(100);
        court.snk.move(court);
        court.foodList.remove(0);
        food = new Poison(300, 300, 130, 130, court.snk);
        court.foodList.add(food);
        food.setPx(130);
        food.setPy(90);
        court.snk.move(court);
        court.foodList.remove(0);
        assertEquals(court.snk.getSize(), 1);
       }
	
	
	
	@Test
	public void testCreateSnakeAndMove()
	{
		final JLabel status = new JLabel("Running...");
		final GameCourt court = new GameCourt(status);
		court.reset();
		court.snk.move(court);
		court.snk.setDirection(Direction.LEFT);
		court.snk.move(court);
		assertEquals(court.snk.getHeadX(), 120);
		assertEquals(court.snk.getHeadY(), 120);
	}
	
	@Test
	public void eatTwoConsecutiveOranges()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        court.foodList.removeAll(court.foodList);
        Food food = new Orange(300, 300, 130, 130, court.snk);
        court.foodList.add(food);
        food.setPx(130);
        food.setPy(120);
        court.snk.move(court);
        court.foodList.removeAll(court.foodList);
        food = new Orange(300, 300, 130, 130, court.snk);
        court.foodList.add(food);
        food.setPx(130);
        food.setPy(110);
        court.snk.move(court);
        assertEquals(court.snk.getSize(), 9);
	}
	
	@Test
	public void testPoisonChangesSnakeSize()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        Food food = new Poison(300, 300, 130, 130, court.snk);
        food.changeSnakeSize(court.snk);
        assertEquals(court.snk.getSize(), 4);
	}
	
	@Test
	public void getFoodListMaintainsEncapsulation()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        List<Food> l1 = court.getFoodList();
        l1.remove(0);
        List<Food> l2 = court.getFoodList();
        assertEquals(l2.size(), 2);
	}
	
	@Test
	public void testIncreasePartsForSizeOne()
	{
		final JLabel status = new JLabel("Running...");
        final GameCourt court = new GameCourt(status);
        court.reset();
        court.foodList.remove(1);
        court.foodList.remove(0);
        Food food = new Poison(300, 300, 130, 130, court.snk);
        court.foodList.add(food);
        food.setPx(130);
        food.setPy(120);
        court.snk.move(court);
        
        court.foodList.removeAll(court.foodList);
        food = new Poison(300, 300, 130, 130, court.snk);
        court.foodList.add(food);
        food.setPx(130);
        food.setPy(110);
        court.snk.move(court);
 
        court.foodList.removeAll(court.foodList);
        food = new Poison(300, 300, 130, 130, court.snk);
        court.foodList.add(food);
        food.setPx(130);
        food.setPy(100);
        court.snk.move(court);

        court.foodList.removeAll(court.foodList);
        food = new Poison(300, 300, 130, 130, court.snk);
        court.foodList.add(food);
        food.setPx(130);
        food.setPy(90);
        court.snk.move(court);
    
        court.foodList.removeAll(court.foodList);
        food = new Apple(300, 300, 130, 130, court.snk);
        court.foodList.add(food);
        food.setPx(130);
        food.setPy(80);
        court.snk.move(court);
        assertEquals(court.snk.getSize(), 2);
	}
	
}
