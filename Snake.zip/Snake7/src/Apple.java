import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;
import javax.imageio.ImageIO;
public class Apple extends Food
{
public static final String IMG_FILE = "files/apple.jpg";
	private BufferedImage img;
	
	public Apple(int courtWidth, int courtHeight, int snakeHeadX, int snakeHeadY, Snake snk)
	{
		super(courtWidth, courtHeight);
		try {
            if (img == null) {
                img = ImageIO.read(new File(IMG_FILE));
            }
        } catch (IOException e) {
            System.out.println("Internal Error2:" + e.getMessage());
        }
		this.setPosition(snakeHeadX, snakeHeadY, snk);
		setTimer(100);
	}
	
	
	/**
	 * This function sets the position of the apple less than 50 pixels away from the head of the
	 * snake
	 * @param co-ordinates of the head of the Snake and the Snake object itself
	 */
	@Override
	public void setPosition(int snakeHeadX, int snakeHeadY, Snake snk)
	{ 
		int x;
		int y;
		double dist;
		do
		{
			x = (int) (Math.random()*290);
			y = (int) (Math.random()*290);
			int absx = Math.abs(x - snakeHeadX);
			int absy = Math.abs(y - snakeHeadY);
			dist = Math.sqrt(Math.pow(absx, 2) + Math.pow(absy, 2));
			
		} while (dist > 50 || (snk.containsSnake(x, y)));
		this.setPx(x);
		this.setPy(y);
	}
	
	public void draw (Graphics g)
	{
		g.drawImage(img, this.getPx(), this.getPy(), this.getHeight(), this.getWidth(), null);
	}
	
	/**
	 * This function changes the score by 1
	 * 
	 */
	@Override
	public void modifyScore()
	{
		GameCourt.score += 1;
	}
	
	/**
	 * This function increases the size of the Snake
	 * @param the Snake object whose size is to be increased
	 */
	@Override
	public void changeSnakeSize(Snake snk)
	{
		snk.increaseParts();
	}
	
}
	