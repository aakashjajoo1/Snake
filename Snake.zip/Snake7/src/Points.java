public class Points {

	// This represents the co-ordinates of a certain object on the screen, which could either
	// be the snake or a piece of food.
	private int x, y;

	public Points(int a, int b)
	{
		x = a;
		y = b;
		
	}
	
	public int getX()
	{
		return x;
	}
	
	public int getY()
	{
		return y;
	}
	
}
