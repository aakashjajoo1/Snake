
public enum Direction {
	UP, DOWN, LEFT, RIGHT; //enum containing the four directions
}
