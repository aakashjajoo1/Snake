=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=
CIS 120 Game Project README
PennKey: aakashj1
=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=

===================
=: Core Concepts :=
===================

- List the four core concepts, the features they implement, and why each feature
  is an appropriate use of the concept. Incorporate the feedback you got after
  submitting your proposal.

  1. Collections: I use a LinkedList to store the basic model of the game, i.e the position
  	of the Snake. The Collection stores objects of the Points class, which contain two integer 
  	fields to hold the x and the y co-ordinates. As the snake moves, the last element of the List
  	is removed and a new element is added at the head of the List. 
  	
  	I also use a List to store the two Food objects I have on the screen at all times. The reason 
  	why I use a List is because adding and removing elements is easy, and also because each Food 
  	object has a timer associated with it, and it disappears after the timer expires. 
  	
  	This is an appropriate use of the concept as storing the Snake in a 2-D array or any other data
  	structure would make the process of moving the Snake or obtaining its position at any given 
  	time very complicated. 

  2. Inheritance: I use inheritance to share data between the different Food Objects (Apples,
  	Oranges and Poison) and also between the two kinds of Game objects (Food and Snake). 
  	
  	The Food objects share functions like modifyScore() (the Apple increases score by 1, the Orange
  	increases score by 2 and Poison decreases the score by 1), setPosition() (the distance of a 
  	Food item is directly proportional to the number of points it offers and Poison has the same
  	position criteria as Oranges), and changeSnakeSize(). Each food item updates the size of the 
  	Snake based on the number of points it offers. 
  	
  	Thus, since these three different kinds of Food objects use the same function in different ways
  	, inheritance is appropriately used here.
  	

  3. File I/O: File I/O allows me to store the high scores of users across multiple instances of
  	the game. Whenever a user's game ends, their score is written onto the file and then sorted.
  	After that, the top 3 scores (if available) are displayed using a popup box. If three scores are
  	not available, then the scores that are available are displayed.
  	
  	This is an appropriate use of File I/O as the data on the file is not erased when the game is
  	closed. So, even when a new user enters the game, they can see their performance relative to
  	other who have played the game previously. If not for File I/O, the user would only be able to 
  	see their scores. Thus, this is an appropriate use of File I/O.
  
  4. JUnit Testing: The Snake, Food and the board are the most important states of my game.
  	In the testing, I exhaustively check the presence of the Snake at different points on the board,
  	I check the state of the game when the Snake hits a wall or itself. I also test the growth or
  	decrease in size of the Snake when it eats food. I try to check the end states of the game
  	when it either eats too much poison and has no parts left or collides with the wall.
  	I also check whether the state of my game is encapsulated and does not allow users to
  	externally change the state of the game. I also check whether the Snake moves appropriately when
  	its direction is changed. I also extensively test the functions that I use to add and remove
  	Food objects from my list of Food. Thus, it is an appropriate use of the concept as it tests 
  	the state extensively.

=========================
=: Your Implementation :=
=========================

- Provide an overview of each of the classes in your code, and what their
  function is in the overall game.
  
  Apple, Orange and Poison are subclasses of the Food class. They override the abstract functions in
  the Food class. Each one of them is placed on the board differently and modifies the score and 
  size of the snake differently. They are used to create Food objects on the screen and update the
  score when the Snake eats them.
  
  The Game class provides the basic frame of the GUI. It sets up the size of my frame, the buttons
  on it, and the control panel. It also takes in the name of the user (until a valid input is
  entered), and stores it in the name field to be written on the file containing the High scores.
  
  The GameCourt class updates the state of the game with each tick. A timer is created and the 
  Snake is moved with every tick at regular intervals of time. As the snake moves, the state of the
  game is updated accordingly (score increases, size of the snake changes, game potentially ends).
  It also allows the user to use the arrow keys to change the direction of the Snake. The GUI
  visible to the user is updated here.
  
  GameObj is a class that represents the main objects of my Game, the Snake and the Food. It
  contains field pertinent to all the objects on the screen, such as their position and velocity. It
  allows checking if two objects collide or intersect, and makes an object bounce off the wall.
  
  The Snake class contains the most important data, the points where the Snake is present. It also
  contains the functions that are used to write onto the file, sort the data in the file and display
  the information in the file. The function that moves the Snake and updates the state of the game
  accordingly is also present here, along with the function that increases or decreases the size of
  the Snake.
  
  The Direction class contains Enums to represent the four cardinal directions. 
  
- Were there any significant stumbling blocks while you were implementing your
  game (related to your design, or otherwise)?

	Yes, I had a bit of difficulty figuring out how to represent my Snake. I initially tried to use 
	2-D array but the process of moving the Snake became very complicated. So, I switched to using
	a Linked List that contains the points where the Snake is present.
	
	I also had difficulty determining how to represent the co-ordinates. Ultimately, I decided to
	use a Class that stores two integer fields to represent the co-ordinates.

- Evaluate your design. Is there a good separation of functionality? How well is
  private state encapsulated? What would you refactor, if given the chance?

Yes, the functionality is mostly well separated. Each object contains the functionality needed to 
create it and place it on the board appropriately. The Game class makes the GUI, GameObj and its
subclasses represent the pieces on the board. GameCourt updates the state at each interval. The
functions that return the locations of the Food or Game objects only provide copies of the original
lists and hence, cannot be modified by an external user.

If given the chance, I would try to make the movement of the snake more detached from the tick()
function to test it easily. I would also try to modify the file I/O section to allow easier
testing.


========================
=: External Resources :=
========================

- Cite any external resources (libraries, images, tutorials, etc.) that you may
  have used while implementing your game.
  https://www.amazon.com/dev-ray-Red-Dot/dp/B07DH81C9S (The red dot representing my Snake)
  https://kottke.org/18/08/the-etymology-of-orange-which-came-first-the-color-or-the-fruit
  https://www.shutterstock.com/search/poisoning
  123rf.com (Apple)