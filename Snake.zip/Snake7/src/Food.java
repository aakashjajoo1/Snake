public abstract class Food extends GameObj {
	
	
	public Food(int courtWidth, int courtHeight)
	{
		super(0, 0, 50, 50, 10, 10, courtWidth, courtHeight);
	}
	
	private int timer;
	
	// Abstract functions common to Apple, Orange and Poison
	public abstract void setPosition(int snakeHeadX, int snakeHeadY, Snake snk);
	
	public abstract void modifyScore();
	
	public abstract void changeSnakeSize(Snake snk);
	
	/**
	 * Gets the value of the timer
	 * @return time remaining for object before it is deleted
	 */
	public int getTimer()
	{
		return timer;
	}
	
	/**
	 * Sets the timer of an object
	 * @param x Value for timer to be set to.
	 */
	public void setTimer(int x)
	{
		timer = x;
	}
}
	
