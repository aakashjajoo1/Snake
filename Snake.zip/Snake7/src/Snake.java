import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;


public class Snake extends GameObj {

	private List<Points> snakePoints;
	private static final String IMG_FILE = "files/RSnake.png";
	private BufferedImage img;
	private Direction d;
	
	public Snake(int courtWidth, int courtHeight)
	{
		super(0, 4, 130, 130, 10, 10, courtWidth, courtHeight);
		snakePoints = new LinkedList<Points>();
		try {
            if (img == null) {
                img = ImageIO.read(new File(IMG_FILE));
            }
        } catch (IOException e) {
            System.out.println("Internal Error 3:" + e.getMessage());
        }
		d = Direction.UP;
		
		// The Snake is initalized with 5 parts
		Points first = new Points(130, 130);
		Points second = new Points(130, 140);
		Points third = new Points(130, 150);
		Points fourth = new Points(130, 160);
		Points fifth = new Points(130, 170);
		snakePoints.add(first);
		snakePoints.add(second);
		snakePoints.add(third);
		snakePoints.add(fourth);
		snakePoints.add(fifth);
	}
	
	/**
	 * This function draws all parts of the Snake
	 */
	public void draw (Graphics g)
	{
		
		Iterator<Points> i = snakePoints.iterator();
		while (i.hasNext())
		{
			Points x = i.next();
			g.drawImage(img, x.getX(), x.getY(), this.getHeight(), this.getWidth(), null);
		}
		
	}
	
	/**
	 * This function returns all the points the snake is on
	 * @return A List of Points the Snake is pm
	 */
	 public List<Points> getSnakePoints()
	 {
		 return new LinkedList<Points>(snakePoints);
	 }
	
	 /**
	  * This function checks if the Snake has collided with itself
	  * @return true if the Snake has collided with itself, false otherwise
	  */
	public boolean snakeCollidesWithSelf()
    {
    	Iterator<Points> i = snakePoints.iterator();
    	if (snakePoints.size() > 3)
    	{
    		i.next();
    		i.next();
    		while (i.hasNext())
    		{
    			Points snake = i.next();
    			int x = snake.getX();
    			int y = snake.getY();
    			int snakeHeadX = getHeadX();
    			int snakeHeadY = getHeadY();
    		
    			int xDist = Math.abs(x - snakeHeadX);
    			int yDist = Math.abs(y - snakeHeadY);
    			if (xDist <= 5 && yDist <= 5)
    			{
    			return true;
    			}
    		}
    	}
    	
    	return false;
    }
	
	/**
	 * This function checks if the Snake has hit some food
	 * @param f The Food object to be checked
	 * @return True if the Snake has hit the food, false otherwise.
	 */
	public boolean snakeHitsFood(Food f)
	{
		
			int foodX = f.getPx();
			int foodY = f.getPy();
		
			int headX = getHeadX();
			int headY = getHeadY();
		
			int xDist = Math.abs(foodX - headX);
			int yDist = Math.abs(foodY - headY);
			
			if (xDist <= 5 && yDist <= 5)
			{
				return true;
			}
		
			
		return false;
	}
	
	// Getter and setter methods
	public void setDirection(Direction n)
	{
		d = n;
	}
	
	public Direction getDirection()
	{
		return d;
	}
	
	public int getHeadX()
	{
		Points head = snakePoints.get(0);
		return head.getX();
	}
	
	public int getHeadY()
	{
		Points head = snakePoints.get(0);
		return head.getY();
	}
	
	public int size()
	{
		return snakePoints.size();
	}
	
	/** 
	 * This is the main logic of the game. As the Snake moves, the last element of the snake body
	 * is deleted and a new element is added at the front, based on the direction the Snake is
	 * moving in.
	 */
	@Override
	public void move(GameCourt court) 
	{	
		Points originalHead = snakePoints.get(0);
		int size = snakePoints.size();
		snakePoints.remove(size-1);
		int orgHeadX = originalHead.getX();
		int orgHeadY = originalHead.getY();
		Points newHead = null;
		switch (d)
		{
			case UP: newHead = new Points(orgHeadX, orgHeadY - 10);
					 snakePoints.add(0, newHead);
					 break;
			
			case DOWN : newHead =  new Points(orgHeadX, orgHeadY + 10);
						snakePoints.add(0, newHead);
						break;
					
			case LEFT : newHead = new Points(orgHeadX - 10, orgHeadY);
						snakePoints.add(0, newHead);
						break;
					
			case RIGHT: newHead = new Points(orgHeadX + 10, orgHeadY);
						snakePoints.add(0, newHead);
						break;
		}
		 
		this.setPx(getHeadX());
		this.setPy(getHeadY());
	
		//The following code checks if the snake has gone out of bounds or collided with itself
		if (court.snk.getHeadX() < 0 || court.snk.getHeadY() < 0 
				|| court.snk.getHeadX() > court.snk.getMaxX() ||
				 court.snk.getHeadY() >  court.snk.getMaxY() || court.snk.snakeCollidesWithSelf())
		{
			GameCourt.playing = false;
			court.setStatus("");
			writeToFile(); //Name and score is written on the file
			sortFileInfo();//The file is sorted
			displayFileInfo();//The top 3 scores are displayed, if available.
			return;
		}
	
		List<Food> tempList = new LinkedList<Food>(court.getFoodList());
		
		Iterator<Food> i = tempList.iterator();
		
		//This loop checks if the Snake has hit any Food object and updates the state of the game
		//accordingly
		while (i.hasNext())
		{
			Food f = i.next();
			if (court.snk.snakeHitsFood(f))
			{
				
				court.removeFromFoodList(f);
				court.addToFoodList(court.genRandomFood());
				
				f.changeSnakeSize(court.snk);
				f.modifyScore();
				GameCourt.score = court.snk.getSize();
				if (court.snk.getSize() == 0)
				{
					GameCourt.playing = false;
					return;
				}
				
			}
		}
	
		List<Food> copy = new LinkedList<Food>(court.getFoodList());
		Iterator<Food> it = copy.iterator();
		int loopVar = 0;
		//The following loop updates the timer for each Food object and checks if the timer
		// of any object has reached zero and updates the game accordingly.
		while (it.hasNext())
		{
		  Food obj = it.next();
		  obj.setTimer(obj.getTimer()-1);
		  if (obj.getTimer() <= 0)
		  {
			  court.removeFromFoodList(loopVar);
			  court.addToFoodList(loopVar, court.genRandomFood());
		  }
		  loopVar++;
		}
		
		
	}
	
	/**
	 * This function adds new parts to the Snake
	 * If there is only one Snake part, the new part is added according to the direction of the head
	 * Else, the new part is added according to the direction of the part before the tail.
	 */
	public void increaseParts()
	{
		if (snakePoints.size() == 1)
		{
			switch (d)
			{
				case UP: snakePoints.add(new Points(getHeadX(), getHeadY() + 10));
					     break;
					 
				case DOWN: snakePoints.add(new Points(getHeadX(), getHeadY() - 10));
			     		break;
				case LEFT: snakePoints.add(new Points(getHeadX() + 10, getHeadY()));
			     		break;
				case RIGHT: snakePoints.add(new Points(getHeadX() - 10, getHeadY()));
						break;
				default: break;
			}
			return;
		}
		
		Points tail = snakePoints.get(snakePoints.size() - 1);
		Points beforeTail = snakePoints.get(snakePoints.size() - 2);
		int tailX = tail.getX();
		int tailY = tail.getY();
		int xDiff = beforeTail.getX() - tailX;
		int yDiff = beforeTail.getY() - tailY;
		if (xDiff == 10)
		{
			Points newTail = new Points(tailX - 10, tailY);
			snakePoints.add(newTail);
		}
		else if (xDiff == -10)
		{
			Points newTail = new Points(tailX + 10, tailY);
			snakePoints.add(newTail);
		}
		else if (yDiff == 10)
		{
			Points newTail = new Points(tailX, tailY - 10);
			snakePoints.add(newTail);
		}
		else
		{
			Points newTail = new Points(tailX, tailY + 10);
			snakePoints.add(newTail);
		}
	}
	
	public void removeLast()
	{
		snakePoints.remove(snakePoints.size()-1);
	}
	
	public int getSize()
	{
		return snakePoints.size();
	}
	
	/**
	 * This function checks if a point contains a part of the Snake body
	 * @param x X-coordinate of the point
	 * @param y Y-coordinate of the point
	 * @return true if a Snake part is on the point, false otherwise
	 */
	public boolean containsSnake(int x, int y)
	{
		Iterator<Points> i = snakePoints.iterator();
		while (i.hasNext())
		{
			Points point = i.next();
			int xDiff = Math.abs(x - point.getX());
			int yDiff = Math.abs(y - point.getY());
			if (xDiff <= 10 && yDiff <= 10)
			{
				return true;
			}
		}
		return false;
	}
	
	/**
	 * this function writes the name of the current user and latest score onto the file
	 */
	public void writeToFile()
    {
    	try
    	{
    		FileWriter fw = new FileWriter("files/HighScore", true);
    		BufferedWriter bw = new BufferedWriter(fw);
    		PrintWriter pw = new PrintWriter(bw);
    		pw.print(GameCourt.name);
    		System.out.print(GameCourt.name);
    		for (int i = GameCourt.name.length(); i <= 8; i++)
    		{
    			pw.print(" ");
    		}
    		pw.print(GameCourt.score);
    		pw.println();
    		pw.close();
    		bw.close();
    		fw.close();
    	}
    	catch (IOException e)
    	{
    		System.out.println(e.getMessage());
    	}
    }
    
	/**
	 * This function sorts the information on the file according to descending order of score
	 */
    public void sortFileInfo()
    {
    	try
    	{
    		File f = new File ("files/HighScore");
    		if (f.length() == 1)
    		{
    			return;
    		}
    		FileReader fr = new FileReader("files/HighScore");
    		BufferedReader br = new BufferedReader(fr);
    		String txt = null;
    		List<String> list1 = new ArrayList<String>();
    		List<String> list2 = new ArrayList<String>();
    		
    		while ((txt = br.readLine()) != null)
    		{
    			String s[] = txt.split(" ");
    			list1.add(s[0]);
    			list2.add(s[s.length-1]);
    		}
    		
    		br.close();
    		fr.close();
    		
    		String s1 [] = new String [list1.size()];//Array containing names
    		String s2 [] = new String [list2.size()];//Array containing scores
    		
    		for (int i = 0; i < list1.size(); i++) 
    		{
                s1[i] = list1.get(i);
                s2[i] = list2.get(i);
    		}
    		
    		sortTwoArraysAccordingToFirstArgument(s2, s1);
    		
    		list1 = Arrays.asList(s1);
    		list2 = Arrays.asList(s2);
    		
    		//Arrays are re-written onto the file, but sorted this time.
    		File f1 = new File("files/HighScore");
    		FileWriter fw = new FileWriter(f1);
    		BufferedWriter bw = new BufferedWriter(fw);
    		PrintWriter pw = new PrintWriter(bw);
    		
    		Iterator<String> iter = list1.iterator();
    		Iterator<String> iter2 = list2.iterator();
    		
    		while (iter.hasNext() && iter2.hasNext())
    		{
    			String s = iter.next();
    			pw.print(s);
    			for (int i = s.length(); i < 8; i++)
    			{
    				pw.print(" ");
    			}
    			String s5 = iter2.next();
    			pw.print(s5);
    			pw.println();
    		}
    		pw.close();
    		bw.close();
    		fw.close();
    	}
    	catch (IOException e)
    	{
    		System.out.println(e.getMessage());
    	}
    }
    
    //Selection sort helper function that sorts two arrays according to the first one
    private void sortTwoArraysAccordingToFirstArgument(String a[], String b[])
    {
    	 for (int i = 0; i < b.length - 1; i++)  
         {  
             int index = i;  
             for (int j = i + 1; j < b.length; j++)
             {  
                 if (Integer.parseInt(a[j]) > Integer.parseInt(a[index]))
                 {  
                     index = j; 
                 }  
             }  
             String temp = b[index];   
             b[index] = b[i];  
             b[i] = temp;  
             temp = a[index];   
             a[index] = a[i];  
             a[i] = temp;
         }  
    }
    
    /**
     * Function that displays the scores in the file
     */
    public void displayFileInfo()
    {
    	try
    	{
    		FileReader fr = new FileReader("files/HighScore");
			BufferedReader br = new BufferedReader(fr);
    		String txt = null;
    		String s = "Name" + "   " + "Score";
    		File f = new File("files/HighScore");
    		if (f.length() < 3)
    		{
    			while ((txt = br.readLine()) != null)
    			{
    				s += "\n" + txt;
    			}
    		}
    		else
    		{
    			int loopVar = 0;
    			while ((txt = br.readLine()) != null && loopVar < 3)
    			{
    				s += "\n" + txt;
    				loopVar++;
    			}
    			
    		}
    		JOptionPane.showMessageDialog(null, s);
    	}
    	catch (IOException e)
    	{
    		System.out.println(e.getMessage());
    	}
    }
	
	
}