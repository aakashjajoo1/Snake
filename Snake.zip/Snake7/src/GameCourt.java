
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * GameCourt
 * 
 * This class holds the primary game logic for how different objects interact with one another. Take
 * time to understand how the timer interacts with the different methods and how it repaints the GUI
 * on every tick().
 */
@SuppressWarnings("serial")
public class GameCourt extends JPanel 
{

    // the state of the game logic
	protected static int score;
    protected Snake snk;
    protected List<Food> foodList;
    
    public static boolean playing = false; // whether the game is running 
    private JLabel status; // Current status text, i.e. "Running..." or "Game Over"
    
    // Game constants
    public static final int COURT_WIDTH = 300;
    public static final int COURT_HEIGHT = 300;
    static String name; // The name of the current player

    
    // Update interval for timer, in milliseconds
    public static 
    final int INTERVAL = 100;

    public GameCourt(JLabel status) 
    {
        // creates border around the court area, JComponent method
        setBorder(BorderFactory.createLineBorder(Color.BLACK));

        
        // The timer is an object which triggers an action periodically with the given INTERVAL. We
        // register an ActionListener with this timer, whose actionPerformed() method is called each
        // time the timer triggers. We define a helper method called tick() that actually does
        // everything that should be done in a single timestep.
        Timer timer = new Timer(INTERVAL, new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                tick();
            }
        });
        timer.start(); 

        // Enable keyboard focus on the court area.
        // When this component has the keyboard focus, key events are handled by its key listener.
        setFocusable(true);
        
        addKeyListener(new KeyAdapter() 
        {
            public void keyPressed(KeyEvent e) 
            { //Funcion to set the direction based on the keyboard keys that are pressed
                if (e.getKeyCode() == KeyEvent.VK_LEFT) 
                {
                	if (!(snk.getDirection() == Direction.RIGHT))
                	{
                    snk.setDirection(Direction.LEFT);
                    snk.setVx(-4);
                    snk.setVy(0);
                	}
                } else if (e.getKeyCode() == KeyEvent.VK_RIGHT) 
                {
                	if (!(snk.getDirection() == Direction.LEFT))
                	{
                	 snk.setDirection(Direction.RIGHT);
                	 snk.setVx(4);
                	 snk.setVy(0);
                	}
                } else if (e.getKeyCode() == KeyEvent.VK_DOWN) 
                {
                	if (!(snk.getDirection() == Direction.UP))
                	{
                	 snk.setDirection(Direction.DOWN);
                	 snk.setVy(-4);
                	 snk.setVx(0);
                	}
                } else if (e.getKeyCode() == KeyEvent.VK_UP) 
                {
                	if (!(snk.getDirection() == Direction.DOWN))
                	{
                	 snk.setDirection(Direction.UP);
                	 snk.setVy(4);
                	 snk.setVx(0);
                	}
                }
            }
        });

        
        

      this.status = status;
    }
    /**
     * This function returns the food objects currently in play
     * @return A List containing the Food objects currently in play.
     */
    public List<Food> getFoodList()
    {
    	return new LinkedList<Food>(foodList);
    }
    
    /**
     * This function generates a random food object based on a random number that is generated
     * @return The generated food object
     */
    public Food genRandomFood()
    {
    	double ran = Math.random();
		if (ran < 0.5)
		{
			return new Apple(COURT_WIDTH, COURT_HEIGHT,
				  snk.getHeadX(), snk.getHeadY(), snk);
		}
		else if (ran >= 0.5 && ran < 0.75)
		{	
			return new Orange(COURT_WIDTH, COURT_HEIGHT,
				 snk.getHeadX(), snk.getHeadY(), snk);
		}	
		else
		{
			return new Poison(COURT_WIDTH, COURT_HEIGHT,
				 snk.getHeadX(), snk.getHeadY(), snk);
		}
    }
    
    /**
     * This function is executed at regular intervals and makes the state of the game move
     * forward.
     */
    void tick()
    {
    	
    	if (playing)
    	{
    		if (snk.getSize() == 0) //If the size of the Snake is zero, the game gets over.
    		{
    			playing = false;
    			return;
    		}
    		snk.move(this);
    		
    		if (playing)
    		{
    			status.setText("Running! Score: " + snk.getSize());
    		}
    		repaint();
    	}
    }
    
    
    /**
     * This function sets the name of the player
     * @param s The name of the player
     */
    public static void setNameTo(String s)
    {
    	name = s;
    }
    
    /**
     * This function sets the state of the game to what it was before the game started
     */
    public void reset()
    {
    	 snk = new Snake(COURT_WIDTH, COURT_HEIGHT);
    	 foodList = new LinkedList<Food>();
    	 foodList = (LinkedList<Food>) foodList;
    	 foodList.add(genRandomFood());
    	 foodList.add(genRandomFood());
    	 playing = true;
         status.setText("Running..." );
         score = snk.getSize();
         // Making sure that this component has the keyboard focus
         requestFocusInWindow();
    }
    
    /**
     * The snake and food are drawn
     */
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        snk.draw(g);
        Iterator<Food> i = foodList.iterator();
        while (i.hasNext())
        {
        	Food food = i.next();
        	food.draw(g);
        }
    }
    
    
    /**
     * The following functions are self explanatory helper functions
     * @param s
     */
    public void setStatus(String s)
    {
    	status.setText("Game Over! Score: " + snk.getSize());
    }
    
    public void removeFromFoodList(Food f)
    {
    	foodList.remove(f);
    }
    
    public void removeFromFoodList(int f)
    {
    	foodList.remove(f);
    }
    
    public void addToFoodList(Food f)
    {
    	foodList.add(f);
    }
    
    public void addToFoodList(int i, Food f)
    {
    	foodList.add(i, f);
    }
    
    @Override
    public Dimension getPreferredSize() {
        return new Dimension(COURT_WIDTH, COURT_HEIGHT);
    }
    
 }

